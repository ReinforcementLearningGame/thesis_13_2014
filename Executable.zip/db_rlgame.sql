-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2014 at 01:53 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_rlgame`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_countries`
--

CREATE TABLE IF NOT EXISTS `tbl_countries` (
  `pk_country_id` int(11) NOT NULL,
  `fld_alpha_2` char(10) DEFAULT NULL,
  `fld_alpha_3` char(10) DEFAULT NULL,
  `fld_country_name` varchar(100) DEFAULT NULL,
  `fld_flag` longblob,
  PRIMARY KEY (`pk_country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_game`
--

CREATE TABLE IF NOT EXISTS `tbl_game` (
  `pk_game_id` int(11) NOT NULL AUTO_INCREMENT,
  `fld_time_finished` datetime DEFAULT NULL,
  `fld_time_started` datetime DEFAULT NULL,
  `fld_finished` bit(1) DEFAULT NULL,
  `fld_white_elo_before` float DEFAULT NULL,
  `fld_black_elo_before` float DEFAULT NULL,
  `fld_white_elo_after` float DEFAULT NULL,
  `fld_black_elo_after` float DEFAULT NULL,
  `fld_winner` bit(1) DEFAULT NULL,
  `fk_white_id` int(11) NOT NULL,
  `fk_black_id` int(11) NOT NULL,
  PRIMARY KEY (`pk_game_id`),
  KEY `Reftbl_user2` (`fk_white_id`),
  KEY `Reftbl_user4` (`fk_black_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_moves`
--

CREATE TABLE IF NOT EXISTS `tbl_moves` (
  `pk_move_id` int(11) NOT NULL AUTO_INCREMENT,
  `fld_fromx` int(11) DEFAULT NULL,
  `fld_fromy` char(10) DEFAULT NULL,
  `fld_tox` char(10) DEFAULT NULL,
  `fld_toy` char(10) DEFAULT NULL,
  `fld_white_turn` bit(1) NOT NULL,
  `fld_move_order` int(11) DEFAULT NULL,
  `fld_is_first` bit(1) NOT NULL,
  `fld_is_last` bit(1) NOT NULL,
  `pk_game_id` int(11) NOT NULL,
  PRIMARY KEY (`pk_move_id`),
  KEY `Reftbl_game7` (`pk_game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `pk_user_id` int(11) NOT NULL AUTO_INCREMENT,
  `fld_sd` float DEFAULT NULL,
  `fld_nickname` char(100) DEFAULT NULL,
  `fld_firstname` varchar(50) DEFAULT NULL,
  `fld_lastname` varchar(50) DEFAULT NULL,
  `fld_password` varchar(50) DEFAULT NULL,
  `fld_ELO` float DEFAULT NULL,
  `fld_experience` int(11) DEFAULT NULL,
  `fld_email` varchar(50) DEFAULT NULL,
  `fld_username` varchar(50) DEFAULT NULL,
  `pk_country_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`pk_user_id`),
  KEY `Reftbl_countries1` (`pk_country_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_game`
--
ALTER TABLE `tbl_game`
  ADD CONSTRAINT `Reftbl_user2` FOREIGN KEY (`fk_white_id`) REFERENCES `tbl_user` (`pk_user_id`),
  ADD CONSTRAINT `Reftbl_user4` FOREIGN KEY (`fk_black_id`) REFERENCES `tbl_user` (`pk_user_id`);

--
-- Constraints for table `tbl_moves`
--
ALTER TABLE `tbl_moves`
  ADD CONSTRAINT `Reftbl_game7` FOREIGN KEY (`pk_game_id`) REFERENCES `tbl_game` (`pk_game_id`);

--
-- Constraints for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD CONSTRAINT `Reftbl_countries1` FOREIGN KEY (`pk_country_id`) REFERENCES `tbl_countries` (`pk_country_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
