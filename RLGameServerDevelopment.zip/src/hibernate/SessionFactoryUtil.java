package hibernate;

import java.io.File;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class SessionFactoryUtil {
	
	private static final SessionFactory sessionFactory;
	 
	static {
		try {			
			Configuration	configurations= new Configuration();				
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			HttpSession session = request.getSession();
			File f=new File(session.getServletContext().getRealPath("/WEB-INF/hibernate.cfg.xml"));
			
			// Create the SessionFactory from hibernate.cfg.xml	
			Configuration conf = configurations.configure(f);		
			
			sessionFactory= conf.buildSessionFactory();
			
	
		} catch (Throwable ex) {
			// Make sure you log the exception, as it might be swallowed
			System.err.println("Initial SessionFactory creation failed " + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}
	 
	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}