package entities;

import java.util.ArrayList;

public class Rlboard  implements Cloneable{

	public static final int EMPTY=0;
	public static final int WHITE=1;
	public static final int BLACK=2;	
	public static final int OPPONENT_INVADED=-1;
	public static final int FINISHED=2;
	public static final int LEGAL=0;
	public static final int ILLEGAL=1;
	
	public int[][] board = new int[8][8];

	private int whitebase;
	private int blackbase;
	
	private int whitecheckerscaptured;
	private int blackcheckerscaptured;
	private int turn;
	private boolean gameover;
	private int winner;
	
	
	

	public Rlboard()
	{
		
		initBoard();
	}
	
	public void initBoard()
	{
		this.whitebase=10;
		this.blackbase=10;
		this.turn=WHITE;
		this.blackcheckerscaptured=0;
		this.whitecheckerscaptured=0;
		gameover=false;
		for (int x=0; x<8; x++)
		{
			for(int y=0; y<8; y++)
			{
				/*if(!((x<2 && y<2) || (x>5 && y>5 )))*/
				{ board[x][y]=EMPTY;}
			}
		}
	}

	public ArrayList<Move> moveGenerator(Rlboard board)
	{
		ArrayList<Move> movelist = new ArrayList<Move>();
		
		if (gameover == false)
		{
			if (board.getTurn() == WHITE)
			{
				if(board.whitebase > 0)
				{
					if (board.board[0][2] == EMPTY)
					{
						Move mo = new Move(0,0,0,2);
						movelist.add(mo);
					}
					if (board.board[1][2] == EMPTY)
					{
						Move mo = new Move(0,0,1,2);
						movelist.add(mo);
					}
					if (board.board[2][0] == EMPTY)
					{
						Move mo = new Move(0,0,2,0);
						movelist.add(mo);
					}
					if (board.board[2][1] == EMPTY)
					{
						Move mo = new Move(0,0,2,1);
						movelist.add(mo);
					}
					
					if (board.board[5][6] == WHITE)
					{
						Move mo = new Move(5,6,7,7);
						movelist.add(mo);
					}
					if (board.board[5][7] == WHITE)
					{
						Move mo = new Move(5,7,7,7);
						movelist.add(mo);
					}
					if (board.board[6][5] == WHITE)
					{
						Move mo = new Move(6,5,7,7);
						movelist.add(mo);
					}
					if (board.board[7][5] == WHITE)
					{
						Move mo = new Move(7,5,7,7);
						movelist.add(mo);
					}
					
				}	
					
				for (int i=0; i<8; i++)
				{	
					for (int j=0; j<8; j++)
					{
						if (board.board[i][j] == WHITE)
						{
							
							for (int m = i-1; m < i+2; m++)
							{
								for (int n = j-1; n< j+2; n++)
								{
									if(m >= 0 && n >= 0 && m < 8 && n < 8 &&
											!(m == 1 && m == 0) && !(m == 0 && n == 1) && !(m == 1 && n == 1)  &&
											!(m == 5 && m == 6) && !(m == 6 && n == 5) && !(m == 6 && n == 6)&&	
											Math.max(m, n) >= Math.max(i,j) && !(Math.abs(m-i)+Math.abs(n-j) == 2) && 
											board.board[m][n] == EMPTY)
									{
										Move mo = new Move(i,j,m,n);
										movelist.add(mo);
										
									}
								} 
							}
							
							
						}
					}	
				}	
					
			}
			
			if (board.getTurn() == BLACK)
			{
				if (board.blackbase > 0)
				{
					if (board.board[0][2] == BLACK)
					{
						Move mo = new Move(0,2,0,0);
						movelist.add(mo);
					}
					if (board.board[1][2] == BLACK)
					{
						Move mo = new Move(1,2,0,0);
						movelist.add(mo);
					}
					if (board.board[2][0] == BLACK)
					{
						Move mo = new Move(2,0,0,0);
						movelist.add(mo);
					}
					if (board.board[2][1] == BLACK)
					{
						Move mo = new Move(2,1,0,0);
						movelist.add(mo);
					}
					
					if (board.board[5][6] == EMPTY)
					{
						Move mo = new Move(7,7,5,6);
						movelist.add(mo);
					}
					if (board.board[5][7] == EMPTY)
					{
						Move mo = new Move(7,7,5,7);
						movelist.add(mo);
					}
					if (board.board[6][5] == EMPTY)
					{
						Move mo = new Move(7,7,6,5);
						movelist.add(mo);
					}
					if (board.board[7][5] == EMPTY)
					{
						Move mo = new Move(7,7,7,5);
						movelist.add(mo);
					}
				}	
				
				for (int i=0; i<8; i++)
				{	
					for (int j=0; j<8; j++)
					{
						if (board.board[i][j] == BLACK)
						{
							
							for (int m = i-1; m < i+2; m++)
							{
								for (int n = j-1; n< j+2; n++)
								{
									if(m >= 0 && n >= 0 && m < 8 && n < 8 && 
									!(m == 1 && m == 0) && !(m == 0 && n == 1) && !(m == 1 && n == 1)  && 
									!(m == 5 && m == 6) && !(m == 6 && n == 5) && !(m == 6 && n == 6)&&	
									Math.max(8-m, 8-n) >= Math.max(8-i,8-j) && !(Math.abs(m-i)+Math.abs(n-j) == 2) 
									&& board.board[m][n] == EMPTY)
									{
										Move mo = new Move(i,j,m,n);
										movelist.add(mo);
										
									}
								} 
							}
						}
					}	
				}	
			}
		}
		return movelist;
		
	}
		

	public void applyMove(Move move)
	{
		if(gameover == false)
		{	
			int fromX = move.getFromX();
			int fromY = move.getFromY();
			int toX = move.getToX();
			int toY = move.getToY();
			int maxfrom = fromX > fromY ? fromX :fromY;
			int maxto = toX > toY ? toX :toY;
			

			
			int maxfromBlack = (8 - fromX) > (8-fromY) ?(8 - fromX) : (8 - fromY);
			int maxtoBlack = (8 - toX) > (8-toY) ? (8 - toX) : (8 - toY);
			
			int absDifX = fromX>toX ? fromX-toX : toX-fromX;
			int absDifY = fromY>toY ? fromY-toY : toY-fromY;
			
			if(turn== BLACK && toX==0 && toY==0 && (
			  (fromX==2 && fromY==0)||(fromX==2 && fromY==1)||
			  (fromX==1 && fromY==2)||(fromX==0 && fromY==2)
			  ))
			{
				winner=BLACK;
				whitebase=OPPONENT_INVADED;
				board[fromX][fromY]=EMPTY;
				setGameover(true);
			}
			else if(turn== WHITE && toX==7 && toY==7 &&(
			   (fromX==5 && fromY==6)||(fromX==5 && fromY==7)||
			   (fromX==6 && fromY==5)||(fromX==7 && fromY==5)
			   ))
			{
				winner=WHITE;
				blackbase=OPPONENT_INVADED;
				board[fromX][fromY]=EMPTY;
				setGameover(true);
			}	
			else if(board[toX][toY]==EMPTY)
			{
	
				if ((turn== WHITE &&  whitebase!= EMPTY && fromX==0 && fromY==0 ) && 
					((toX==2 && toY==0)||(toX==2 && toY==1) ||
					(toX==1 && toY==2)||(toX==0 && toY==2) ) )
				{
					whitebase--;
					board[toX][toY]=WHITE;
					turn=BLACK;
					removechecker_new(toX,toY);
				}
				else if(turn== BLACK && blackbase!= EMPTY && fromX==7 && fromY==7 &&  (
						(toX==5 && toY==6)||(toX==5 && toY==7)||
						(toX==6 && toY==5)||(toX==7 && toY==5)
						))
				{
					blackbase--;
					board[toX][toY]=BLACK;
					turn=WHITE;
					removechecker_new(toX,toY);
				}
				else if(turn == WHITE && board[fromX][fromY] == WHITE   )
				{
					if(maxfrom <= maxto && 
							((absDifX==0 && absDifY==1)|| 
							(absDifX==1 && absDifY==0)))
					{
						/*System.out.println("to fromx einai: "+fromX+" kai to fromy einai:"+ fromY+"to tox einai: "+toX+" kai to toy einai:"+ toY);
						System.out.println("to maxfrom einai: "+maxfrom+" kai to maxto einai:"+ maxto+"legal move");*/
						board[fromX][fromY]=EMPTY;
						board[toX][toY]=WHITE;
						turn=BLACK;
						removechecker_new(toX,toY);
					}
				}
				else if(turn == BLACK && board[fromX][fromY] == BLACK)
				{
					if (maxtoBlack >= maxfromBlack && 
							((absDifX==0 && absDifY==1)|| 
							(absDifX==1 && absDifY==0)))
					{
						board[fromX][fromY]=EMPTY;
						board[toX][toY]=BLACK;
						turn=WHITE;
						removechecker_new(toX,toY);
					}
				}
			}	
		}
	}
	
	public void removechecker_new(int toX, int toY)
	{
		boolean whitebasesurrounded=true;
		if(board[0][2]==EMPTY||board[1][2]==EMPTY||board[2][1]==EMPTY||board[2][0]==EMPTY)
		
		{
			whitebasesurrounded=false;
		}
		if(whitebasesurrounded==true)
		{
			whitecheckerscaptured+=whitebase;
			whitebase=0;
		}
		boolean blackbasesurrounded=true;
	
		if(board[5][7]==EMPTY||board[5][6]==EMPTY||board[6][5]==EMPTY||board[7][5]==EMPTY)
		
		{
			blackbasesurrounded=false;
		}
		if(blackbasesurrounded==true)
		{
			blackcheckerscaptured+=blackbase;
			blackbase=0;
		}
	
		boolean whitecheckerblocked=true;
		for(int x=toX-1; x<toX+2 ;x++)
		{
			for(int y=toY-1; y<toY+2; y++)
			{
				if(x>=0 && y>=0 && x<8 && y<8 && !(x==1 && y==0) && !(x==0 && y==1) && !(x==1 && y==1) && !(x==6 && y==7) && !(x==7 && y==6) && !(x==6 && y==6) && board[x][y]==WHITE)
				{	
					for (int i=x-1;i<x+2;i++)
					{
						for (int j=y-1;j<y+2;j++)
						{
							if(i>=0 && j>=0 && i<8 && j<8 && !(i==1 && j==0) && !(i==0 && j==1) && !(i==1 && j==1)  && 
							 Math.max(i, j)>=Math.max(x,y) && !(Math.abs(x-i)+Math.abs(y-j)==2) && board[i][j]==EMPTY)
							{
								/*System.out.println("kat arxhn mpainei edw1");
								System.out.println("x="+x+"y="+y+"i="+i+"j="+j);*/
								whitecheckerblocked=false;
							}
						} 
					}
					
					if( whitecheckerblocked==true)
					{
						//System.out.println("removing white checker"+x+y);
						board[x][y]=EMPTY;
						whitecheckerscaptured+=1;
					}
					whitecheckerblocked=true;
				}
		}	
	}
	
	boolean blackcheckerblocked=true;
	for(int x=toX-1; x<toX+2 ;x++)
	{
		for(int y=toY-1; y<toY+2; y++)
		{
			if(x>=0 && y>=0 && x<8 && y<8 && !(x==1 && y==0) && !(x==0 && y==1) && !(x==1 && y==1) && !(x==6 && y==7) && !(x==7 && y==6) && !(x==6 && y==6) && board[x][y]==BLACK  )
			{
				for (int i=x-1;i<x+2;i++)
				{
					for (int j=y-1;j<y+2;j++)
					{
						//System.out.println("mporei na mphke edw mesa");
						if(i>=0 && j>=0 && i<8 && j<8 && !(i==6 && j==7) && !(i==7 && j==6) && !(i==6 && j==6) &&
							 Math.max(i, j)<=Math.max(x,y) && !(Math.abs(x-i)+Math.abs(y-j)==2) && board[i][j]==EMPTY)
						{
							/*System.out.println("omws den mphke edw");
							System.out.println("kat arxhn mpainei edw2");
							System.out.println("x="+x+"y="+y+"i="+i+"j="+j);*/
							blackcheckerblocked=false;
						}
					} 
				}
				if(blackcheckerblocked==true)
				{
					//System.out.println("removing white checker"+x+y);
					board[x][y]=EMPTY;
					blackcheckerscaptured+=1;
				}
			}	
			blackcheckerblocked=true;
		}	
	} }

	
	public int getWinner() {
		return winner;
	}
	public void setWinner(int winner) {
		this.winner = winner;
	}
	public int[][] getBoard() {
		return board;
	}
	public void setBoard(int[][] board) {
		this.board = board;
	}
	
	public void removechecker(int toX, int toY)
	{
		boolean whitebasesurrounded=true;
		if(board[0][2]==EMPTY||board[1][2]==EMPTY||board[2][1]==EMPTY||board[2][0]==EMPTY)
		
		{
			whitebasesurrounded=false;
		}
		if(whitebasesurrounded==true)
		{
			whitecheckerscaptured+=whitebase;
			whitebase=0;
		}
		boolean blackbasesurrounded=true;
	
		if(board[5][7]==EMPTY||board[5][6]==EMPTY||board[6][5]==EMPTY||board[7][5]==EMPTY)
		
		{
			blackbasesurrounded=false;
		}
		if(blackbasesurrounded==true)
		{
			blackcheckerscaptured+=blackbase;
			blackbase=0;
		}
	
		boolean whitecheckerblocked=true;
		for(int x=toX-1; x<toX+2 ;x++)
		{
			for(int y=toY-1; y<toY+2; y++)
			{
				if(x>=0 && y>=0 && x<8 && y<8 && !(x==1 && y==0) && !(x==0 && y==1) && !(x==1 && y==1) && !(x==6 && y==7) && !(x==7 && y==6) && !(x==6 && y==6) && board[x][y]==WHITE)
				{	
					for (int i=x-1;i<x+2;i++)
					{
						for (int j=y-1;j<y+2;j++)
						{
							if(i>=0 && j>=0 && i<8 && j<8 && !(i==1 && j==0) && !(i==0 && j==1) && !(i==1 && j==1) && !(i==6 && j==7) && !(i==7 && j==6) && !(i==6 && j==6) && 
							 Math.max(i, j)>=Math.max(x,y) && !(Math.abs(x-i)+Math.abs(y-j)==2) && board[i][j]==EMPTY)
							{
								/*System.out.println("kat arxhn mpainei edw1");
								System.out.println("x="+x+"y="+y+"i="+i+"j="+j);*/
								whitecheckerblocked=false;
							}
						} 
					}
					
					if( whitecheckerblocked==true)
					{
						System.out.println("removing white checker"+x+y);
						board[x][y]=EMPTY;
						whitecheckerscaptured+=1;
					}
					whitecheckerblocked=true;
				}
		}	
	}
	
	boolean blackcheckerblocked=true;
	for(int x=toX-1; x<toX+2 ;x++)
	{
		for(int y=toY-1; y<toY+2; y++)
		{
			if(x>=0 && y>=0 && x<8 && y<8 && !(x==1 && y==0) && !(x==0 && y==1) && !(x==1 && y==1) && !(x==6 && y==7) && !(x==7 && y==6) && !(x==6 && y==6) && board[x][y]==BLACK  )
			{
				for (int i=x-1;i<x+2;i++)
				{
					for (int j=y-1;j<y+2;j++)
					{
						System.out.println("mporei na mphke edw mesa");
						if(i>=0 && j>=0 && i<8 && j<8 && !(i==6 && j==7) && !(i==7 && j==6) && !(i==6 && j==6) && !(i==1 && j==0) && !(i==0 && j==1) && !(i==1 && j==1) &&
							 Math.max(i, j)<=Math.max(x,y) && !(Math.abs(x-i)+Math.abs(y-j)==2) && board[i][j]==EMPTY)
						{
							/*System.out.println("omws den mphke edw");
							System.out.println("kat arxhn mpainei edw2");
							System.out.println("x="+x+"y="+y+"i="+i+"j="+j);*/
							blackcheckerblocked=false;
						}
					} 
				}
				if(blackcheckerblocked==true)
				{
					System.out.println("removing white checker"+x+y);
					board[x][y]=EMPTY;
					blackcheckerscaptured+=1;
				}
			}	
			blackcheckerblocked=true;
		}	
	} 
}
			
	public boolean isGameover() {
		return gameover;
	}
	public void setGameover(boolean gameover) {
		this.gameover = gameover;
	}
	public int getWhitebase() {
		return whitebase;
	}
	public void setWhitebase(int whitebase) {
		this.whitebase = whitebase;
	}
	public int getBlackbase() {
		return blackbase;
	}
	public void setBlackbase(int blackbase) {
		this.blackbase = blackbase;
	}

	public int getTurn() {
		return turn;
	}
	public void setTurn(int turn) {
		this.turn = turn;
	}
	public static int getEmpty() {
		return EMPTY;
	}
	public static int getWhite() {
		return WHITE;
	}
	public static int getBlack() {
		return BLACK;
	}
	public static int getOpponentInvaded() {
		return OPPONENT_INVADED;
	}
	public static int getFinished() {
		return FINISHED;
	}
	public static int getLegal() {
		return LEGAL;
	}
	public static int getIllegal() {
		return ILLEGAL;
	}
	public int getWhitecheckerscaptured() {
		return whitecheckerscaptured;
	}
	public void setWhitecheckerscaptured(int whitecheckerscaptured) {
		this.whitecheckerscaptured = whitecheckerscaptured;
	}

	public int getBlackcheckerscaptured() {
		return blackcheckerscaptured;
	}

	public void setBlackcheckerscaptured(int blackcheckerscaptured) {
		this.blackcheckerscaptured = blackcheckerscaptured;
	}

}


