package entities;

import hibernate.SessionFactoryUtil;

import java.util.Date;

import org.hibernate.Session;

import pojos.TblGame;
import pojos.TblUser;

public class PlayedGame {

	public String wuser;
	public String buser;
	public Rlboard board;
	public TblGame game;

	public PlayedGame(String w, String b)
	{
		this.setWuser(w);
		this.setBuser(b);
		board = new Rlboard();
		
	}
	
	public PlayedGame(TblUser w, TblUser b)
	{
		this.setWuser(w.getFldNickname());
		this.setBuser(b.getFldNickname());
		this.game = new TblGame();
		this.game.setTblUserByFkWhiteId(w);
		this.game.setTblUserByFkBlackId(b);
		this.game.setFldWhiteEloBefore(w.getFldElo());
		this.game.setFldBlackEloBefore(b.getFldElo());
		this.game.setFldTimeStarted(new Date());
		this.game.setFldFinished(false);
		board = new Rlboard();
		Session session = SessionFactoryUtil.getSessionFactory().getCurrentSession();
		session.getTransaction().begin();
		session.saveOrUpdate(game);
		session.getTransaction().commit();
		
	}
	
	public void updateFinishedGame(TblUser w, TblUser b, boolean winner)
	{
		this.game.setFldTimeFinished(new Date());
		this.game.setFldWhiteEloAfter(w.getFldElo());
		this.game.setFldBlackEloAfter(b.getFldElo());
		this.game.setFldFinished(true);
		this.game.setFldWinner(winner);
		Session session = SessionFactoryUtil.getSessionFactory().getCurrentSession();
		session.getTransaction().begin();
		session.saveOrUpdate(game);
		session.getTransaction().commit();
	}
	

	public TblGame getGame() {
		return game;
	}

	public void setGame(TblGame game) {
		this.game = game;
	}
	
	public String getWuser() {
		return wuser;
	}
	public void setWuser(String wuser) {
		this.wuser = wuser;
	}
	public String getBuser() {
		return buser;
	}
	public void setBuser(String buser) {
		this.buser = buser;
	}
	public Rlboard getBoard() {
		return board;
	}
	public void setBoard(Rlboard board) {
		this.board = board;
	}
	
}
