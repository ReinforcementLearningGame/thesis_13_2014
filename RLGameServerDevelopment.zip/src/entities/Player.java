package entities;

import java.util.List;

public class Player {
	
	private int id;
	private String nickname;
	private String password;
	private boolean ingame;
	private int gameid;
	private List <Invitations> from;
	private List <Invitations> to;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isIngame() {
		return ingame;
	}

	public void setIngame(boolean ingame) {
		this.ingame = ingame;
	}

	public int getGameid() {
		return gameid;
	}

	public void setGameid(int gameid) {
		this.gameid = gameid;
	}

	public List<Invitations> getFrom() {
		return from;
	}

	public void setFrom(List<Invitations> from) {
		this.from = from;
	}

	public List<Invitations> getTo() {
		return to;
	}

	public void setTo(List<Invitations> to) {
		this.to = to;
	}
}
