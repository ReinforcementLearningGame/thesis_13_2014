package staticfunctions;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;







import hibernate.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class Static {

	public static final int UPDATE=0;
	public static final int RESULT=1;
	
	public static final int GET=0;
	public static final int SET=1;
	
	public static ArrayList <Object> query(String hql,Object[] args)
	{
		List rs=null;
		ArrayList<Object> list= new ArrayList<Object>();
		Session session = SessionFactoryUtil.getSessionFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		Query q=session.createQuery(hql);
				
		if(args!=null)
		{
			ArrayList <Object> arguments= new ArrayList<Object>();
			Collections.addAll(arguments,args);
			for (int i=0; i< arguments.size();i++)
			{
				
				if(arguments.get(i)  instanceof String)
				{q.setString(i,(String) arguments.get(i)); }
				
				else if (arguments.get(i)  instanceof Integer)
				{q.setInteger(i,(Integer) arguments.get(i)); }
				else if ( arguments.get(i) instanceof Byte)
				{q.setByte(i, (Byte) arguments.get(i));}
				
			}
		}
		rs=q.list();
		tx.commit();
		
		for (Iterator iter = rs.iterator(); iter.hasNext();){
			//System.out.println("1");
			list.add(iter.next());
		} 
		
		return list;
		
	}
	
	public static HttpSession getsession()
	{
		
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		HttpSession session = request.getSession();
		return session;
			
	}
	
	public static  byte booleanToByte(boolean bool)
    {
    	byte   vOut =   (byte) (bool?1:0);
    	return vOut;
    	
    }
	
	

    public static boolean ByteToboolean(byte b)
    {
    	if (b==1)
    		return true;
    	else
    		return false;
    	
    	
    }
	
}
