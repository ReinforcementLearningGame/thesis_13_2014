package beans;


import java.io.Serializable;
import java.util.Date;

import javax.faces.application.FacesMessage;  
import javax.faces.context.FacesContext;  
import javax.servlet.http.HttpServlet;

import org.primefaces.context.RequestContext;  
import org.primefaces.event.DragDropEvent;
import org.primefaces.push.PushContext;  
import org.primefaces.push.PushContextFactory;  

import entities.Invitations;
import entities.Move;
import entities.Rlboard;
import view.ActiveInvitations;
import view.ChatUsers;
import view.Games;
  
public class ChatViewBean implements Serializable{  
      
    private final PushContext pushContext = PushContextFactory.getDefault().getPushContext();  
   
    private ActiveInvitations invitations; // global bean
    private ChatUsers users; // another global bean
    private Games games; // global bean too
  
    private String privateMessage;  
    private String globalMessage;  
    
  	private boolean loggedIn;  
    private String privateUser;  
      
    private final static String CHANNEL = "/chat/";  
    private final static String CHANNEL2 = "/game/";
  
    /*game details*/
    private String username;  
    private String opponent;
    private boolean ingame=false;
    private int gameid=-1;
    private Rlboard board;
    private boolean iswhite;
    private boolean isover;
    /*game details*/

	public void login() 
    {  
        RequestContext requestContext = RequestContext.getCurrentInstance();  
        
        if(users.contains(username))
        {
        	loggedIn = false;  
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Username taken", "Try with another username."));  
            requestContext.update("growl");  
        }  
        else 
        {  
            users.addPlayer(username); 
            pushContext.push(CHANNEL + "*", username + " joined the channel.");
            requestContext.execute("subscriber.connect('/" + username + "')");
            requestContext.execute("subscriber2.connect('/" + username + "')");
            loggedIn = true;  
        }  
    }  

	public void botlogin() 
	{
		//users.addPlayer(username);
		pushContext.push(CHANNEL + "*", username + " joined the channel.");
		pushContext.push(CHANNEL + "*", "hello from bot");
		System.out.println("to username einai:"+username);
	}
	
	public void sendGlobal() 
	{  
        pushContext.push(CHANNEL + "*", username + ": " + globalMessage);  
        globalMessage = null;  
    }  
      
    public void sendPrivate() 
    {  
        pushContext.push(CHANNEL + privateUser, "[PM] " + username + ": " + privateMessage);  
        privateMessage = null;  
    } 
    
    public void disconnect() 
    {  
        //remove user and update ui  
        users.removeUser(username);
        RequestContext.getCurrentInstance().update("form:users"); 
        //push leave information
        if(this.isIngame())
        {	
        	this.games.removeGame(username, opponent);
        }
        pushContext.push(CHANNEL + "*", username + " left the channel.");  
        //reset state  
        loggedIn = false;  
        username = null; 
    }  
            
    public String handleCommand(String command, String[] params) 
    {  
       	if(command.equals("greet"))
    	{	
            return "Hello " + params[0];  
    	}
    	else if(command.equals("date"))
    	{
            return new Date().toString();  
    	}
        else if (command.equals("invite"))
        {
        	if (users.contains(params[0]))
        	{
        		if(invitations.contains(new Invitations(username, params[0])))
        		{
        			return "you have already invited" + params[0];
        		}
        		else
        		{	
	        		Invitations inv = new Invitations(username,params[0]);
	        		invitations.addInvitation(inv);
	        		pushContext.push(CHANNEL + "*", username + " invites "+params[0]);
	        		return command+" succesful";
        		}
        	}
        	else
        	{
        		return "there is no player with such name logged in at the moment";
           	}
        }
        else if(command.equals("accept"))
        {
        	
           	RequestContext request = RequestContext.getCurrentInstance();
        	if(invitations.contains(new Invitations(params[0], username)))
        	{
        		this.setIngame(true);
        		this.setIswhite(false);
        		this.opponent= new String(params[0]);
        		
        		//games.addNewGame(params[0], username);
        		
        		games.addNewGame(users.getPlayer(params[0]), users.getPlayer(username));
        		
        		gameid=games.getgameid(username);
         		request.update("form");
        		pushContext.push(CHANNEL + "*", username + " accepts invitation of "+params[0]);
        		pushContext.push(CHANNEL + params[0],username+" accepted your invitation!");
                invitations.removeInvitations(params[0], username);
        		return username+" accepts invitation of "+ params[0];
        	}
        	else
        	{
        		return params[0]+" hasn't invited "+username;
        	}
        }
        else if (command.equals("ranking"))
        {
        	return users.rankings();
        }
    	
        else  
        {
            return command + " not found";
        }
    }  
        
    public void ondrop(DragDropEvent ddEvent)
    {
    	//Parse ddEvent and get source and destination square
      	String draggedId = ddEvent.getDragId();
    	//Client id of dropped component
    	//System.out.println(droppedId);	
    	Object data = ddEvent.getData();
    	//System.out.println(data);
    	String from = ddEvent.getDragId();
    	//System.out.println("from"+from);
    	
		String to = ddEvent.getDropId();
		//System.out.println("to"+data);
		from = from.substring(11);
		to= to.substring(8);
		int fromx = Integer.parseInt(from.substring(0,1));
		int fromy = Integer.parseInt(from.substring(1));
		int tox = Integer.parseInt(to.substring(0,1));
		int toy = Integer.parseInt(to.substring(1));
		// System.out.println("fromx"+fromx+"fromy"+fromy+"tox"+tox+"toy"+toy);
		
		//Create a new Move object from source and destination square
		Move move = new Move();
		move.setFromX(fromx);
		move.setFromY(fromy);
		move.setToX(tox);
		move.setToY(toy);
		
		//apply the move to the game
		games.getPlayedgames().get(gameid).getBoard().applyMove(move);
				
		//remove the game and update players ratings if it is over
		int  over = 0;
		if(this.getBoard().isGameover())
		{
			users.updatePlayerRating(username, opponent);
			this.games.finishGame(users.getPlayer(username), users.getPlayer(opponent), !iswhite);
			this.games.removeGame(username, opponent);
	    	over = 1;
			pushContext.push(CHANNEL + "*", username +" won a match against " + opponent+"!");  
		}
		//Push changes to clients
		RequestContext.getCurrentInstance().update("form:gamecontainer"); 
		pushContext.push(CHANNEL2 + opponent, over+","+username );
		pushContext.push(CHANNEL2 + username, over+","+username );
	}
    
    public void exitGame()
    {
    	this.ingame = false;
    	this.gameid = -1;
       	this.opponent = null;
    	RequestContext.getCurrentInstance().update("form:gamecontainer"); 
    }
    
    public boolean isIngame() 
    {
       	if (games.getgameid(username)!= -1 )
    	{
    		gameid = games.getgameid(username);
    		ingame = true;
    		if(username.equals(games.getPlayedgames().get(gameid).getWuser()))
    		{
    			opponent = games.getPlayedgames().get(gameid).getBuser();
    			setIswhite(true);
    		}	
    		else
    		{
    			opponent = games.getPlayedgames().get(gameid).getWuser();
    			setIswhite(false);
    		}
    	}
    	else 
    	{	
    		ingame = false;
    		this.gameid = -1;
    		this.opponent = null;
    	}
		return ingame;
	}

	public void setIngame(boolean ingame) {
		this.ingame = ingame;
	}
	
	public Rlboard getBoard() {
		return games.getPlayedgames().get(gameid).getBoard();
	}

	public void setBoard(Rlboard board) {
			this.board = board;
	}
	
	public String getOpponent() {
			return opponent;
	}

	public void setOpponent(String opponent) {
			this.opponent = opponent;
	}
	

	public void setUsers(ChatUsers users) {  
        this.users = users;  
    }  
  
    public ActiveInvitations getInvitations() {
		return invitations;
	}

	public void setInvitations(ActiveInvitations invitations) {
		this.invitations = invitations;
	}

	public String getPrivateUser() {  
        return privateUser;  
    }  
  
    public void setPrivateUser(String privateUser) {  
        this.privateUser = privateUser;  
    }  
  
    public String getGlobalMessage() {  
        return globalMessage;  
    }  
  
    public void setGlobalMessage(String globalMessage) {  
        this.globalMessage = globalMessage;  
    }  
  
    public String getPrivateMessage() {  
        return privateMessage;  
    }  
  
    public void setPrivateMessage(String privateMessage) {  
        this.privateMessage = privateMessage;  
    }  
      
    public String getUsername() {  
        return username;  
    }  
    public void setUsername(String username) {  
        this.username = username;  
    }  
      
    public boolean isLoggedIn() {  
        return loggedIn;  
    }  
    public void setLoggedIn(boolean loggedIn) {  
        this.loggedIn = loggedIn;  
    }  
     
    public Games getGames() {
		return games;
	}

	public void setGames(Games games) {
		this.games = games;
	}

	public boolean isIswhite() {
		return iswhite;
	}

	public void setIswhite(boolean iswhite) {
		this.iswhite = iswhite;
	}

	private boolean isIsover() {
		if(isIngame() &&  getBoard().isGameover())
			return true;
		else 
			return false;
	}

	public void setIsover(boolean isover) {
		this.isover = isover;
	}
}



