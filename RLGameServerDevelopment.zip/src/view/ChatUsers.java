package view;	

import hibernate.SessionFactoryUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.Iterator;
import pojos.TblUser;
import entities.Player;
import staticfunctions.Rating;

public class ChatUsers implements Serializable {
   
    private List <TblUser> players;
    
   @PostConstruct
    public void init() 
   	{
	   this.players= new ArrayList<TblUser>();
   	}
   
    public void addPlayer(String player)
    {
    	if(searchPlayerInDB(player)==false)
    	{
    		TblUser us= new TblUser();
    		us.setFldElo((float) 1500);
    		us.setFldExperience(0);
    		us.setFldSd((float) 350);
    		us.setFldNickname(player);
    		
    		Session session = SessionFactoryUtil.getSessionFactory().getCurrentSession();
    		session.getTransaction().begin();
    		session.save(us);
    		session.getTransaction().commit();
    		
    		this.players.add(us);
       	}	
    	else
    	{}	
    }
    
    public boolean searchPlayerInDB(String player)
    {
    	
    	Session session = SessionFactoryUtil.getSessionFactory().getCurrentSession();
		session.getTransaction().begin();
		List us= session.createQuery("from TblUser").list(); 
		for (Iterator it = (Iterator) us.iterator() ; it.hasNext();  )
		{
			TblUser user= (TblUser) it.next();
			if(player.equals(user.getFldNickname()))
			{this.players.add(user);
				return true;
			}
		}
		session.getTransaction().commit();
	  	return false;
    }
   
    public void removeUser(String player) 
    {
       	for (int i =0; i< players.size();i++)
       	{
       		if (players.get(i).getFldNickname().equals(player))
    		{	
    			players.remove(i);
    		}
       	}
    }
   
    public String rankings()
    {
    	String report = ""; 
		Session session = SessionFactoryUtil.getSessionFactory().getCurrentSession();
		session.getTransaction().begin();
		List us= session.createQuery("from TblUser order by fldElo desc").list();
		int i=0;
		for (Iterator it = (Iterator) us.iterator() ; it.hasNext();  )
		{
			i++;
			TblUser user= (TblUser) it.next();
			String record = i+":"+user.getFldNickname()+" "+user.getFldElo()+"/"+user.getFldSd()+"<br>";
			report= report+record;
		}
		session.getTransaction().commit();
		return report;
    }
        
    public void updatePlayerRating(String pl1,String pl2)
    {
	
	 TblUser player1 = new TblUser();
	 TblUser player2 = new TblUser();
	
	 Session session = SessionFactoryUtil.getSessionFactory().getCurrentSession();
	 session.getTransaction().begin();
	 List us= session.createQuery("from TblUser").list(); 
	 for (Iterator it = (Iterator) us.iterator() ; it.hasNext();  )
	 {
		TblUser user= (TblUser) it.next();
		if(pl1.equals(user.getFldNickname()))
		{
			player1= user;
		}
		if(pl2.equals(user.getFldNickname()))
		{
			player2= user;
		}
	 }
	 
	 if(player1 == null || player2 ==null )
	 {
		 System.out.println("rating: enas ap tous dyo den yparxei") ;
		 
	 } 
	 else
	 {	 
		 /*System.out.println("rating:"+player1.getFldSd());
		 System.out.println("rating:"+player2.getFldSd());
		 System.out.println("rating:"+player1.getFldElo());
		 System.out.println("rating:"+player2.getFldElo());*/
	 	 Rating[] arr = new Rating[2];
		 arr[0] = new Rating();
		 arr[1] = new Rating();
		 arr[0].setRD(player1.getFldSd());
		 arr[1].setRD(player2.getFldSd());
		 arr[0].rating = player1.getFldElo();
		 arr[1].rating = player2.getFldElo();
		 Rating.calculateRatings(arr);
		  
		 player1.setFldElo((float)roundoff(arr[0].rating, 2));
		 player2.setFldElo((float)roundoff(arr[1].rating, 2));
		 player1.setFldSd(roundoff(arr[0].RD, 1));
		 player2.setFldSd(roundoff(arr[0].RD, 1));
		 player1.setFldExperience(player1.getFldExperience()+1);
		 player2.setFldExperience(player2.getFldExperience()+1);
		 session.update(player1);
		 session.update(player2);
		 session.getTransaction().commit();
		 for(TblUser pl: players)
		 {
			if (pl.getFldNickname().equals(pl1))
			{
				pl.setFldElo(player1.getFldElo());
				pl.setFldSd(player1.getFldSd());
				pl.setFldExperience(player1.getFldExperience());
			}
			if (pl.getFldNickname().equals(pl2))
			{
				pl.setFldElo(player2.getFldElo());
				pl.setFldSd(player2.getFldSd());
				pl.setFldExperience(player2.getFldExperience());
			}
		 }	
	 } 
}
       
    public float roundoff(double a, int digits)
    {
       	return	(float) (Math.round(a * Math.pow(10.0, digits )) / Math.pow(10.0, digits )) ;
    }
    
    public boolean contains(String player)
    {
    	for(TblUser pl: players)
    	{
    		if (pl.getFldNickname().equals(player))
    		{
    			return true;
    		}
       	}
    	return false;
    }
    
    public TblUser getPlayer(String player)
    {
    	for(TblUser pl: players)
    	{
    		if (pl.getFldNickname().equals(player))
    		{
    			
    			return pl;
    		}
       	}
    	
    	return null;
    }
    
    public List<TblUser> getPlayers() 
	{
		return players;
	}
    
	public void setPlayers(List<TblUser> players) 
	{
		this.players = players;	
	}
    
    
}
