package view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import entities.*;

public class ActiveInvitations implements Serializable{

	
	private List<Invitations> invitations;

@PostConstruct
public void init()
{	
	this.invitations = new ArrayList<Invitations>();
}

public void addInvitation(Invitations invitation)
{
	invitations.add(invitation);
}

public List<Invitations> getInvitations() {
	return invitations;
}

public boolean contains(Invitations invitation)
{
	for (int i=0;i<invitations.size();i++)
	{
		if (invitations.get(i).getFrom().equals(invitation.getFrom())&&invitations.get(i).getTo().equals(invitation.getTo()))
		{
			return true;
		}
	}
	return false;
}

public void setInvitations(List<Invitations> invitations) {
	this.invitations = invitations;
}

public void removeInvitations(String from, String to)
{
	for (int i=0; i < invitations.size(); i++)
	{
		if (invitations.get(i).getFrom().equals(from) && invitations.get(i).getTo().equals(to))
		{
			invitations.remove(i);
		}
	}
}




}