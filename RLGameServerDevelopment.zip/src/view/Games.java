package view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import pojos.TblUser;
import entities.PlayedGame;


public class Games  implements Serializable{

	private List <PlayedGame> playedgames;

	public int getgameid(String name)
	{
		int index = -1;
		for (int i=0; i< playedgames.size(); i++)
		{
			if ((playedgames.get(i).getBoard().isGameover() == false) && (playedgames.get( i ).getWuser().equals(name) || playedgames.get( i ).getBuser().equals(name)));
			{
				index = i;
			}
		
		}
		return index;
	}
	
	public void removeGame(String w, String b)
	{
		for (int i=0; i < playedgames.size(); i++)
		{
			if (playedgames.get(i).getWuser().equals(w) && playedgames.get(i).getBuser().equals(b))
			{
				playedgames.remove(i);
			}
			else if (playedgames.get(i).getWuser().equals(b) && playedgames.get(i).getBuser().equals(w))
			{
				playedgames.remove(i);
			}
			
		}
		
	}
	
	public void finishGame(TblUser w, TblUser b, boolean winner )
	{
		for (int i=0; i < playedgames.size(); i++)
		{
			if (playedgames.get(i).getWuser().equals(w.getFldNickname()) && playedgames.get(i).getBuser().equals(b.getFldNickname()))
			{
				playedgames.get(i).updateFinishedGame(w, b, winner);
			}
			else if (playedgames.get(i).getWuser().equals(b.getFldNickname()) && playedgames.get(i).getBuser().equals(w.getFldNickname()))
			{
				playedgames.get(i).updateFinishedGame(b, w, winner);
			}
			
		}
		
	}

//	public void addNewGame(String w, String b)
//	{
//		PlayedGame p = new PlayedGame(w,b);
//		playedgames.add(p);
//	}
	
	public void addNewGame(TblUser w, TblUser b)
	{
		PlayedGame p = new PlayedGame(w,b);
		playedgames.add(p);
	}
	

	@PostConstruct
    public void init() 
	{
    	this.playedgames= new ArrayList<PlayedGame>();
     
	}
	
	public List<PlayedGame> getPlayedgames() {
		return playedgames;
	}


	public void setPlayedgames(List<PlayedGame> playedgames) {
		this.playedgames = playedgames;
	}




	
}
