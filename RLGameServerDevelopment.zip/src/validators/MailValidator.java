package validators;

import javax.faces.application.FacesMessage;
import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;



public class MailValidator implements Validator, Serializable {

	private static final long serialVersionUID = 1L;

	public void validate(FacesContext facesContext, UIComponent arg1, Object value) throws ValidatorException {
        String inputValue = (String) value;
       
        //int atIndex = inputValue.indexOf("@");
        boolean atIndex = isValidEmailAddress(inputValue);
        if (!atIndex ){
        	FacesMessage facesMessage = new FacesMessage("Invalid Input", "���������� E-mail!");
        	throw new ValidatorException(facesMessage);
        }
    }
	
	
	public boolean isValidEmailAddress(String emailAddress){  
		   String  expression="^[\\w\\-]([\\.\\w])+[\\w]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";  
		   CharSequence inputStr = emailAddress;  
		   Pattern pattern = Pattern.compile(expression,Pattern.CASE_INSENSITIVE);  
		   Matcher matcher = pattern.matcher(inputStr);  
		   return matcher.matches();  
		  
		 }  
	
	
	
}



